"""
parse_alerts.py

Reads Wazuh's JSON alert log, extracts key fields (source IP, username,
rule ID, severity, timestamp), classifies severity, and prints a formatted
SOC-style summary report of the most recent alerts.
"""

import json
from datetime import datetime

ALERTS_FILE = "/var/ossec/logs/alerts/alerts.json"


def classify_severity(level):
    """Map Wazuh rule level to SOC-style severity classification."""
    level = int(level)
    if level <= 4:
        return "Low"
    elif level <= 7:
        return "Medium"
    elif level <= 11:
        return "High"
    else:
        return "Critical"


def parse_alerts(limit=20):
    incidents = []
    with open(ALERTS_FILE, "r") as f:
        lines = f.readlines()

    # Process the most recent alerts first
    for line in reversed(lines[-limit:]):
        try:
            alert = json.loads(line)
        except json.JSONDecodeError:
            continue  # skip any malformed/partial line

        rule = alert.get("rule", {})
        data = alert.get("data", {})

        incident = {
            "timestamp": alert.get("timestamp", "N/A"),
            "rule_id": rule.get("id", "N/A"),
            "description": rule.get("description", "N/A"),
            "level": rule.get("level", 0),
            "severity": classify_severity(rule.get("level", 0)),
            "src_ip": data.get("srcip", "N/A"),
            "src_user": data.get("srcuser", "N/A"),
            "agent": alert.get("agent", {}).get("name", "N/A"),
        }
        incidents.append(incident)

    return incidents


def print_report(incidents):
    print("=" * 70)
    print("SOC ALERT SUMMARY REPORT")
    print("=" * 70)
    for i, inc in enumerate(incidents, 1):
        print(f"\n[{i}] {inc['timestamp']}")
        print(f"    Rule ID     : {inc['rule_id']}")
        print(f"    Description : {inc['description']}")
        print(f"    Level       : {inc['level']}  ->  Severity: {inc['severity']}")
        print(f"    Source IP   : {inc['src_ip']}")
        print(f"    Username    : {inc['src_user']}")
        print(f"    Agent       : {inc['agent']}")
    print("\n" + "=" * 70)


if __name__ == "__main__":
    incidents = parse_alerts(limit=20)
    print_report(incidents)
