"""
incident_report.py

Filters Wazuh alerts for High/Critical severity, deduplicates by source IP +
rule ID, and generates a formal, timestamped SOC incident report (.txt) for
each unique incident.
"""

import json
from datetime import datetime

ALERTS_FILE = "/var/ossec/logs/alerts/alerts.json"
REPORT_THRESHOLD_LEVEL = 10  # Only generate formal reports for High/Critical alerts


def classify_severity(level):
    level = int(level)
    if level <= 4:
        return "Low"
    elif level <= 7:
        return "Medium"
    elif level <= 11:
        return "High"
    else:
        return "Critical"


def get_high_priority_alerts(limit=50):
    """Return only High/Critical alerts, deduplicated by source IP + rule ID combo."""
    seen = set()
    incidents = []

    with open(ALERTS_FILE, "r") as f:
        lines = f.readlines()

    for line in reversed(lines[-limit:]):
        try:
            alert = json.loads(line)
        except json.JSONDecodeError:
            continue

        rule = alert.get("rule", {})
        data = alert.get("data", {})
        level = int(rule.get("level", 0))

        if level < REPORT_THRESHOLD_LEVEL:
            continue  # skip low/medium alerts for formal reports

        src_ip = data.get("srcip", "N/A")
        rule_id = rule.get("id", "N/A")
        dedup_key = f"{src_ip}_{rule_id}"

        if dedup_key in seen:
            continue  # avoid duplicate incidents for the same IP+rule
        seen.add(dedup_key)

        incident = {
            "timestamp": alert.get("timestamp", "N/A"),
            "rule_id": rule_id,
            "description": rule.get("description", "N/A"),
            "level": level,
            "severity": classify_severity(level),
            "src_ip": src_ip,
            "src_user": data.get("srcuser", "N/A"),
            "agent": alert.get("agent", {}).get("name", "N/A"),
        }
        incidents.append(incident)

    return incidents


def generate_report(incident, incident_num):
    now = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"incident_report_{now}_{incident_num}.txt"

    blocked_status = "YES" if incident["level"] >= 12 else "NO"

    report = f"""==============================
SOC INCIDENT REPORT
==============================
Incident ID       : INC-{now}-{incident_num}
Date and Time     : {incident['timestamp']}
Attack Type       : {incident['description']}
Source IP         : {incident['src_ip']}
Target Username   : {incident['src_user']}
Affected System   : {incident['agent']}
Wazuh Rule ID     : {incident['rule_id']}
Severity          : {incident['severity']} (Level {incident['level']})
Description       : Detected via custom Wazuh correlation rule monitoring
                     SSH authentication logs for repeated failed login
                     attempts, indicative of a brute-force attack.
Actions Taken     : Automated active response triggered via Wazuh,
                     invoking iptables-based IP blocking script.
IP Blocked        : {blocked_status}
Status            : RESOLVED
==============================
"""

    with open(filename, "w") as f:
        f.write(report)

    print(f"[+] Report generated: {filename}")
    return filename


if __name__ == "__main__":
    incidents = get_high_priority_alerts(limit=50)
    print(f"Found {len(incidents)} unique high-priority incident(s).\n")

    for idx, inc in enumerate(incidents, 1):
        generate_report(inc, idx)
