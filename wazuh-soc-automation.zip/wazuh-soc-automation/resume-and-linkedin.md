# Resume & LinkedIn Content

## Resume Project Description (choose the length that fits your resume)

### Short version (1-2 bullets)
- Built an automated SOC monitoring and incident response pipeline using Wazuh SIEM across a two-host AWS deployment, featuring custom brute-force detection rules and Python-based alert triage
- Engineered a custom Wazuh correlation rule and Active Response automation that detects SSH brute-force attacks and automatically blocks attacker IPs via iptables, validated against real internet-sourced attacks

### Full version (3-4 bullets)
- Designed and deployed a two-host Wazuh SIEM architecture on AWS EC2 (Manager + Agent), implementing full log pipeline from endpoint to alert dashboard
- Developed custom XML correlation rules to detect SSH brute-force attacks (5+ failed logins within 120 seconds from a single source), mapped to MITRE ATT&CK T1110
- Built a Bash-based Active Response automation that triggers iptables IP blocking on high-severity alerts, with automatic timeout-based unblocking
- Wrote Python automation to parse Wazuh JSON alerts, classify severity (Low/Medium/High/Critical), and auto-generate formatted SOC incident reports
- Validated the system against a genuine, unsolicited internet-sourced brute-force attack, confirming real-world detection accuracy

---

## LinkedIn Post Draft

---

🔐 **Built an automated SOC monitoring & incident response system — and it caught a real attack.**

Over the past few days I built an end-to-end SOC automation project using Wazuh SIEM, deployed across two AWS EC2 instances (Manager + Agent), mirroring how a real security operations environment is structured.

**What it does:**
🔹 Monitors SSH authentication logs in real time
🔹 Custom-built correlation rule detects brute-force attacks (5+ failed logins in 2 minutes from the same IP)
🔹 Automatically triggers an Active Response that blocks the attacker's IP via iptables
🔹 Python automation parses alerts, classifies severity, and generates formatted incident reports
🔹 Detections mapped to MITRE ATT&CK (T1110 — Brute Force)

**The best part?** While testing, the system detected and would have auto-blocked a *genuine* brute-force attempt from the open internet — not a simulated test. Real validation, not just a lab exercise.

This project pulled together a lot of what I've been learning: SIEM administration, detection engineering, security automation, and Python scripting — all wrapped into something that actually works end-to-end.

Full write-up and code on GitHub 👇
[link]

#cybersecurity #SOC #blueteam #wazuh #SIEM #infosec #python #AWS #detectionengineering

---

## GitHub Repository Structure (suggested)

```
wazuh-soc-automation/
├── README.md
├── local_rules.xml              # Custom detection rules
├── active-response/
│   └── block-ip.sh              # Active response script
├── soc-automation/
│   ├── parse_alerts.py          # Alert parser & classifier
│   └── incident_report.py       # Incident report generator
├── sample-reports/
│   └── incident_report_sample.txt
├── screenshots/
│   ├── dashboard-agent-active.png
│   ├── dashboard-bruteforce-alert.png
│   ├── terminal-active-response-log.png
│   └── terminal-python-report.png
└── docs/
    └── architecture-diagram.png
