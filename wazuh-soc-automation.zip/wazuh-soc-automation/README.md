# Automated SOC Monitoring and Incident Response using Wazuh SIEM

A fully functional, end-to-end SOC automation project built on a real two-host AWS deployment. This project demonstrates detection engineering, automated incident response, and SOC-style alert triage — including a **real brute-force attack, detected and auto-blocked in production** during testing (see [Real-World Detection](#real-world-detection) below).

---

## Architecture

```
                    ┌─────────────────────────┐
                    │   Attacker / Internet     │
                    └────────────┬────────────┘
                                 │ SSH brute-force attempts
                                 ▼
                    ┌─────────────────────────┐
                    │   Agent (Monitored Host)  │
                    │   Ubuntu 22.04 — EC2       │
                    │   - Wazuh Agent 4.14.7     │
                    │   - /var/log/auth.log      │
                    └────────────┬────────────┘
                                 │ Encrypted events (port 1514)
                                 ▼
                    ┌─────────────────────────┐
                    │   Manager (SIEM Brain)    │
                    │   Ubuntu 22.04 — EC2       │
                    │   - Wazuh Manager 4.14.7   │
                    │   - Wazuh Indexer          │
                    │   - Wazuh Dashboard        │
                    │   - Custom Detection Rules │
                    └────────────┬────────────┘
                                 │ Rule match (Level 12)
                                 ▼
                    ┌─────────────────────────┐
                    │   Active Response Engine  │
                    │   - block-ip.sh script    │
                    │   - iptables DROP rule    │
                    │   - Auto-expire (10 min)  │
                    └────────────┬────────────┘
                                 │
                                 ▼
                    ┌─────────────────────────┐
                    │   Python Automation       │
                    │   - Alert parser          │
                    │   - Severity classifier    │
                    │   - Incident report gen    │
                    └─────────────────────────┘
```

**Two-host design** — the Manager and Agent run on separate EC2 instances, mirroring real-world SOC architecture where the SIEM brain is decoupled from monitored endpoints.

---

## Tech Stack

| Component | Purpose |
|---|---|
| Wazuh Manager 4.14.7 | SIEM core — log analysis, correlation, alerting |
| Wazuh Agent 4.14.7 | Endpoint log collection |
| Wazuh Dashboard | Visualization & alert triage |
| Ubuntu 22.04 (AWS EC2) | Host OS for both Manager and Agent |
| Bash | Active Response scripting (iptables automation) |
| Python 3.10 | Alert parsing, severity classification, report generation |
| iptables | Firewall-level IP blocking |
| XML | Custom Wazuh detection rules |

---

## What This Project Detects & Automates

1. **Detects** SSH brute-force attacks via a custom two-stage correlation rule
2. **Classifies** severity (Low/Medium/High/Critical) based on Wazuh rule level
3. **Automatically blocks** the attacker's IP using `iptables`, triggered by Wazuh Active Response
4. **Auto-expires** blocks after 10 minutes (prevents permanent lockouts in this lab setup)
5. **Generates** formal, timestamped incident reports in a standard SOC format
6. **Maps detections to MITRE ATT&CK** (T1110 — Brute Force)

---

## Custom Detection Rules

Two correlated rules work together (`/var/ossec/etc/rules/local_rules.xml` on the Manager):

```xml
<rule id="100010" level="10">
  <if_sid>5710</if_sid>
  <description>SSHD Brute Force: Multiple invalid user attempts from same source IP</description>
  <group>authentication_failures,</group>
</rule>

<rule id="100011" level="12" frequency="5" timeframe="120">
  <if_matched_sid>100010</if_matched_sid>
  <same_source_ip />
  <description>SSHD Brute Force Attack Detected: 5+ failed logins from $(srcip) in 2 minutes</description>
  <mitre>
    <id>T1110</id>
  </mitre>
  <group>authentication_failures,brute_force,</group>
</rule>
```

**How it works:**
- **Rule 100010** fires on every individual failed SSH login (building on Wazuh's built-in rule `5710`, "invalid user")
- **Rule 100011** escalates to a **Critical, Level 12** alert when rule `100010` fires **5+ times from the same source IP within 120 seconds** — the signature of a brute-force attempt rather than a one-off mistyped login
- The `<mitre>` tag maps this detection to **MITRE ATT&CK T1110 (Brute Force)**, aligning the project with industry-standard threat frameworks

---

## Active Response — Automated IP Blocking

When rule `100011` fires, Wazuh's Active Response engine pushes a command to the Agent, which runs `block-ip.sh`:

```bash
#!/bin/bash
read INPUT_JSON
SRCIP=$(echo $INPUT_JSON | grep -oP '(?<="srcip":")[^"]*')
ACTION=$(echo $INPUT_JSON | grep -oP '(?<="command":")[^"]*')

if [ "$ACTION" == "add" ]; then
    iptables -I INPUT -s "$SRCIP" -j DROP
    echo "$(date '+%Y/%m/%d %H:%M:%S') - Blocked IP: $SRCIP" >> /var/ossec/logs/active-responses.log
elif [ "$ACTION" == "delete" ]; then
    iptables -D INPUT -s "$SRCIP" -j DROP
    echo "$(date '+%Y/%m/%d %H:%M:%S') - Unblocked IP: $SRCIP" >> /var/ossec/logs/active-responses.log
fi
```

Configured in `ossec.conf` with a **10-minute auto-expiry** (`timeout="600"`), so blocked IPs are automatically released — balancing security response with avoiding permanent lockouts in a lab/demo environment.

---

## Python Automation

Two scripts in `/soc-automation/`:

- **`parse_alerts.py`** — reads `alerts.json`, extracts source IP / username / rule ID / severity / timestamp, and prints a formatted SOC summary
- **`incident_report.py`** — filters for High/Critical alerts only, deduplicates by IP+rule, and generates individual `incident_report_<timestamp>.txt` files in a standard SOC format:

```
==============================
SOC INCIDENT REPORT
==============================
Incident ID       : INC-20260915_095243-2
Date and Time     : 2026-09-15T09:42:56.785+0000
Attack Type       : SSHD Brute Force Attack Detected: 5+ failed logins...
Source IP         : 117.89.254.46
Target Username   : admin
Affected System   : ip-172-31-31-52
Wazuh Rule ID     : 100011
Severity          : Critical (Level 12)
Actions Taken     : Automated active response triggered via Wazuh,
                     invoking iptables-based IP blocking script.
IP Blocked        : YES
Status            : RESOLVED
==============================
```

---

## Real-World Detection

While testing, this system detected and responded to a **genuine, unsolicited brute-force attack** from the public internet (`117.89.254.46`), not a simulated one — proving the pipeline works against real-world traffic, not just lab conditions:

- Rule `100010` fired repeatedly as the attacker attempted the `admin` username against SSH
- Rule `100011` escalated to Critical within the 2-minute correlation window
- The system's design would automatically block real attackers exhibiting this pattern

This is included as evidence that the detection logic generalizes beyond synthetic test scenarios.

---

## Testing Performed

| Test | Result |
|---|---|
| Agent enrollment & connectivity | ✅ Confirmed via Dashboard + CLI |
| SSH log ingestion (`auth.log`) | ✅ Verified via `wazuh-logcollector` |
| Custom rule 100010 (single failed login) | ✅ Verified via `wazuh-logtest` and live alerts |
| Custom rule 100011 (brute-force correlation) | ✅ Triggered after 5 failed logins within 120s |
| Active Response IP block | ✅ Verified via `iptables` + `active-responses.log` |
| Auto-expiry of block | ✅ Confirmed block cleared after 10 minutes |
| Python alert parsing | ✅ Correctly extracted and classified real alerts |
| Incident report generation | ✅ Generated correctly formatted `.txt` reports |
| Real-world attack detection | ✅ Detected genuine internet-sourced brute-force attempt |

---

## Setup Summary

1. Provisioned two Ubuntu 22.04 EC2 instances (Manager + Agent)
2. Installed Wazuh Manager, Indexer, and Dashboard on the Manager host
3. Installed and enrolled Wazuh Agent on the second host, connected via private IP over ports 1514/1515
4. Configured `auth.log` monitoring on the Agent
5. Wrote and tested custom correlation rules for brute-force detection
6. Built and registered an Active Response script for automated IP blocking
7. Wrote Python tooling for alert parsing, severity classification, and incident reporting

---

## Skills Demonstrated

- SIEM deployment and administration (Wazuh)
- Custom detection rule engineering (XML, rule correlation, frequency/timeframe logic)
- MITRE ATT&CK framework mapping
- Security automation / SOAR-style response (Bash, iptables)
- Python scripting for security data processing
- AWS EC2 provisioning, security groups, and networking troubleshooting
- Linux system administration and log analysis

---

## Screenshots

*(See `/screenshots` folder)*

- Wazuh Dashboard — Agent status
- Wazuh Dashboard — Brute-force alert (Rule 100011, Level 12, MITRE T1110)
- Terminal — Active response blocking log
- Terminal — Python incident report output

---

## Author

Built as a hands-on SOC Analyst portfolio project to demonstrate practical detection engineering and automation skills for SOC Analyst / Security Engineer roles.
