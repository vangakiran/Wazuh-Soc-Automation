#!/bin/bash
#
# block-ip.sh
# Wazuh Active Response script — automatically blocks/unblocks an attacker's
# IP address using iptables, triggered when custom rule 100011 (SSH brute-force
# detection) fires on the Wazuh Manager.
#
# Wazuh sends alert data as JSON via stdin. This script extracts the source IP
# and the requested action (add = block, delete = unblock, used for auto-expiry).

read INPUT_JSON
SRCIP=$(echo $INPUT_JSON | grep -oP '(?<="srcip":")[^"]*')
ACTION=$(echo $INPUT_JSON | grep -oP '(?<="command":")[^"]*')

LOCAL_BIN=/var/ossec/active-response/bin
LOG_FILE="/var/ossec/logs/active-responses.log"

if [ "$ACTION" == "add" ]; then
    iptables -I INPUT -s "$SRCIP" -j DROP
    echo "$(date '+%Y/%m/%d %H:%M:%S') - Blocked IP: $SRCIP" >> $LOG_FILE
elif [ "$ACTION" == "delete" ]; then
    iptables -D INPUT -s "$SRCIP" -j DROP
    echo "$(date '+%Y/%m/%d %H:%M:%S') - Unblocked IP: $SRCIP" >> $LOG_FILE
fi

exit 0
